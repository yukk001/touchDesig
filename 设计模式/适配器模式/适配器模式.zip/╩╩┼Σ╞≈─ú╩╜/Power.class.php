<?php
//220�Ĳ�ͷ
class Power {    
	public function get220Power(){    
		return 220;    
	}    
}   