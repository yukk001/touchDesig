<?php

interface Target {
	function get110Power();
}
